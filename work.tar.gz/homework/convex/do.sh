#!/bin/bash

rm ./divide/result
rm ./gra/result
rm ./brute/result
declare -i para=1000
while [ $para -le 10000 ];do
    cd ./divide
    ./m $para >> result
    cd ../gra
    ./m $para >> result
    cd ../brute
    ./m $para >> result
    cd ..
    let para+=1000
done

