#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <float.h>
#include <sys/time.h>
#include <random>
#include <map>

#define LOW 10.5
#define HIG 90.5

using namespace std;

typedef struct t
{
    double x;
    double y;
}DOT;

double erx, ery;

bool cmp(DOT *a, DOT *b)
{
    double x = (a->x-erx)*(b->y-ery)-(b->x-erx)*(a->y-ery);
    if(x<0) return false;
    else return true;
}


bool cmpx(DOT *a, DOT *b)
{
    if(a->x < b->x) {return true;}
    else if(a->x-b->x < DBL_MIN)
    {
        if(a->y < b->y) return true;
        else return false;
    }
    else return false;
}

void genq(fstream &out)
{
    map<int,bool> flag;
    map<int,bool>::iterator ite;
    vector<int> outrec;
    vector<int> inrec;
    random_device rd;
    mt19937 mt(rd());
    
    int i = 0, j = 0 , k;
    while(i+j<10000)
    {
        int x = mt()%1000;
        int y = mt()%1000;
        if(flag.find(x*1000+y)!=flag.end()) continue;

        if(x/10.0 > LOW && x/10.0 < HIG && y/10.0 > LOW && y/10.0 < HIG)
        {
            if(i<9900)
            {
                flag.insert(pair<int,bool>(x*1000+y,true));
                inrec.push_back(x*1000+y);
                i++;
            }
        }
        else
        {
            if(j<100)
            {
                flag.insert(pair<int,bool>(x*1000+y,false));
                outrec.push_back(x*1000+y);
                j++;
            }
        }
    }

    j = 0, k = 0;
    while(j+k<10000)
    {
        double x, y;
        if((j+k+1)%100 == 0)
        {
            x = (outrec[j]/1000)/10.0;
            y = (outrec[j]%1000)/10.0;
            out << x << "\t" << y << endl;
            j++;
        }
        else
        {
            x = (inrec[k]/1000)/10.0;
            y = (inrec[k]%1000)/10.0;
            out << x << "\t" << y << endl;
            k++;
        }
    }
}

void mysort(vector<DOT*> &v)
{
    int i, j, ei, ej;
    for(i=1,ei=v.size();i<ei-1;i++)
    {
        for(j=i+1;j<ei;j++)
        {
            if(!cmp(v[i],v[j]))
            {
                DOT *t = v[i];
                v[i] = v[j];
                v[j] = t;
            }
        }
    }
}

void convex(vector<DOT*> &q, int s, int e, vector<DOT*> &ch)
{
    DOT *v1 = new DOT(), *v2 = new DOT();
    vector<DOT*> lch, rch;

    if(e-s+1 <= 3)
    {
        double minx = DBL_MAX, miny = DBL_MAX;
        int index;
        for(int i=s;i<=e;i++)
        {
            if(q[i]->x < minx)
            {
                minx = q[i]->x;
                miny = q[i]->y;
                index = i;
            }
            else if(q[i]->x-minx < DBL_MIN)
            {
                if(q[i]->y<miny)
                {
                    miny = q[i]->y;
                    index = i;
                }
            }
        }
        DOT * t = q[s];
        q[s] = q[index];
        q[index] = t;
        for(int i=s;i<=e;i++)
            ch.push_back(q[i]);
        return;
    }

    convex(q,s,(e+s)/2,lch);
    convex(q,(e+s)/2+1,e,rch);
    
    erx = lch[0]->x; ery = lch[0]->y;
    lch.insert(lch.end(),rch.begin(),rch.end());
    mysort(lch);
    erx = 0; ery = 0;
    
    for(int i=2,en=lch.size();i<en;i++)
    {
        v1->x = lch[i]->x-lch[i-1]->x;
        v1->y = lch[i]->y-lch[i-1]->y;
        v2->x = lch[i-2]->x-lch[i-1]->x;
        v2->y = lch[i-2]->y-lch[i-1]->y;
        while(!cmp(v1,v2))
        {
            lch.erase(lch.begin()+i-1);
            i--;
            en--;
            v1->x = lch[i]->x-lch[i-1]->x;
            v1->y = lch[i]->y-lch[i-1]->y;
            v2->x = lch[i-2]->x-lch[i-1]->x;
            v2->y = lch[i-2]->y-lch[i-1]->y;
        }
    }
    ch = lch;
}

int main(int argc, char *argv[])
{
    int itera = atoi(argv[1]);
    vector<DOT*> ch;
    fstream in("dot"+string(argv[1]),ios_base::in | ios_base::out | ios_base::trunc);
    ofstream out("divide"+string(argv[1]));
    struct timespec start, end;
    genq(in);
    in.close();
    in.clear();
    in.open("dot"+string(argv[1]));

    for(int i=0;i<itera;i++)
    {
        DOT *t = new DOT();
        in >> t->x >> t->y;
        ch.push_back(t);
    }
    in.close();

    vector<DOT*> dotstack;
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&start);
    sort(ch.begin(),ch.end(),cmpx);

    convex(ch,0,ch.size()-1,dotstack);
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&end);
    cout << itera << "\t" << (end.tv_sec-start.tv_sec)*1000+(end.tv_nsec-start.tv_nsec)/1000000.0 << endl;
    for(int i=0,e=dotstack.size();i<e;i++)
    {
        out << dotstack[i]->x << "\t" << dotstack[i]->y << endl;
    }
    out << dotstack[0]->x << "\t" << dotstack[0]->y << endl;
    return 0;
}
