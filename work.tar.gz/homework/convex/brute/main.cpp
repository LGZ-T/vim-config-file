#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <algorithm>
#include <float.h>
#include <random>
//#include <stdlib.h>
//#include <stdio.h>
#include <sys/time.h>
#define LOW 10.5
#define HIG 90.5

using namespace std;

typedef struct t
{
    double x;
    double y;
    struct t *next;
}DOT;

double erx, ery;

inline double dotmul(DOT *a, DOT *b)
{
    return a->x*b->x+a->y*b->y;
}

bool cmp(DOT *a, DOT *b)
{
    return ((a->x-erx)*(b->y-ery)-(b->x-erx)*(a->y-ery)) > 0;
}

void genq(fstream &out)
{
    map<int,bool> flag;
    map<int,bool>::iterator ite;
    vector<int> outrec;
    vector<int> inrec;
    random_device rd;
    mt19937 mt(rd());
    
    int i = 0, j = 0 , k;
    while(i+j<10000)
    {
        int x = mt()%1000;
        int y = mt()%1000;
        if(flag.find(x*1000+y)!=flag.end()) continue;

        if(x/10.0 > LOW && x/10.0 < HIG && y/10.0 > LOW && y/10.0 < HIG)
        {
            if(i<9900)
            {
                flag.insert(pair<int,bool>(x*1000+y,true));
                inrec.push_back(x*1000+y);
                i++;
            }
        }
        else
        {
            if(j<100)
            {
                flag.insert(pair<int,bool>(x*1000+y,false));
                outrec.push_back(x*1000+y);
                j++;
            }
        }
    }

    j = 0, k = 0;
    while(j+k<10000)
    {
        double x, y;
        if((j+k+1)%100 == 0)
        {
            x = (outrec[j]/1000)/10.0;
            y = (outrec[j]%1000)/10.0;
            out << x << "\t" << y << endl;
            j++;
        }
        else
        {
            x = (inrec[k]/1000)/10.0;
            y = (inrec[k]%1000)/10.0;
            out << x << "\t" << y << endl;
            k++;
        }
    }
}

int main(int argc, char *argv[])
{
    int itera = atoi(argv[1]);
    double x, y;
    fstream in("dot"+string(argv[1]),ios_base::in | ios_base::out | ios_base::trunc);
    ofstream out("brute"+string(argv[1]));
    struct timespec start, end;
    DOT * posible = new DOT(), *cur, *next, *pre, v0, v1, v2;
    cur = posible;
    genq(in);
    in.close();
    in.clear();
    in.open("dot"+string(argv[1]));

    for(int i=0;i<itera;i++)
    {
        next = new DOT();
        next->next = NULL;
        cur->next = next;
        cur = next;
        in >> x >> y;
        cur->x = x;
        cur->y = y;
    }

    in.close();
    DOT *i1 = posible->next, *i2, *i3, *i4;

    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
    while(i1!=NULL)//A
    {
        i2 = i1->next;
        while(i2!=NULL)//B
        {
            i3 = i2->next;
            while(i3!=NULL)//C
            {
                pre = posible;
                i4 = posible->next;
                while(i4!=NULL)//P
                {
                    if(i4==i1 || i4==i2 || i4==i3)
                    {
                        pre = i4;
                        i4 = i4->next;
                        continue;
                    }
                    v0.x = i3->x - i1->x; v0.y = i3->y - i1->y;
                    v1.x = i2->x - i1->x; v1.y = i2->y - i1->y;
                    v2.x = i4->x - i1->x; v2.y = i4->y - i1->y;
                    double u = ((dotmul(&v1,&v1)*dotmul(&v2,&v0)-dotmul(&v1,&v0)*dotmul(&v2,&v1)))/\
                               (dotmul(&v0,&v0)*dotmul(&v1,&v1)-dotmul(&v0,&v1)*dotmul(&v1,&v0));
                    double v = ((dotmul(&v0,&v0)*dotmul(&v2,&v1)-dotmul(&v0,&v1)*dotmul(&v2,&v0)))/\
                               (dotmul(&v0,&v0)*dotmul(&v1,&v1)-dotmul(&v0,&v1)*dotmul(&v1,&v0));
                    if(u > 0 && v >0 && (u+v) < 1)
                    {
                        pre->next = i4->next;
                        delete i4;
                        i4 = pre->next;
                        continue;
                    }
                    pre = i4;
                    i4 = i4->next;
                }
                i3 = i3->next;
            }
            i2 = i2->next;
        }
        i1 = i1->next;
    }
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
    vector<DOT *> poly;
    i1 = posible->next;
    double minx = DBL_MAX, miny = DBL_MAX;
    int i =0;
    int index;
    while(i1!=NULL)
    {
        if(i1->x < minx)
        {
            minx = i1->x;
            miny = i1->y;
            index = i;
        }
        else if(i1->x - minx <DBL_MIN)
        {
            if(i1->y < miny)
            {
                miny = i1->y;
                index = i;
            }
        }

        i1->x -= erx;
        i1->y -= ery;
        poly.push_back(i1);
        i1 = i1->next;
        i++;
    }
    double tx = poly[0]->x;
    double ty = poly[0]->y;
    poly[0]->x = poly[index]->x;
    poly[0]->y = poly[index]->y;
    poly[index]->x = tx;
    poly[index]->y = ty;
    erx = poly[0]->x;
    ery = poly[0]->y;
    sort(poly.begin()+1,poly.end(),cmp);
    cout << itera << "\t"  << (end.tv_sec-start.tv_sec)*1000+(end.tv_nsec-start.tv_nsec)/1000000.0 << endl;
    for(int i=0,e=poly.size();i<e;i++)
    {
        out << poly[i]->x << "\t" << poly[i]->y << endl;
    }
    out << poly[0]->x << "\t" << poly[0]->y << endl;

    return 0;
}
