#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <random>
#include <float.h>
#include <sys/time.h>
#include <map>
#define LOW 10.5
#define HIG 90.5

using namespace std;

typedef struct t
{
    double x;
    double y;
}DOT;

double erx, ery;

bool cmp(DOT *a, DOT *b)
{
    return ((a->x-erx)*(b->y-ery)-(b->x-erx)*(a->y-ery)) > 0;
}

void genq(fstream &out)
{
    map<int,bool> flag;
    map<int,bool>::iterator ite;
    vector<int> outrec;
    vector<int> inrec;
    random_device rd;
    mt19937 mt(rd());
    
    int i = 0, j = 0 , k;
    while(i+j<10000)
    {
        int x = mt()%1000;
        int y = mt()%1000;
        if(flag.find(x*1000+y)!=flag.end()) continue;

        if(x/10.0 > LOW && x/10.0 < HIG && y/10.0 > LOW && y/10.0 < HIG)
        {
            if(i<9900)
            {
                flag.insert(pair<int,bool>(x*1000+y,true));
                inrec.push_back(x*1000+y);
                i++;
            }
        }
        else
        {
            if(j<100)
            {
                flag.insert(pair<int,bool>(x*1000+y,false));
                outrec.push_back(x*1000+y);
                j++;
            }
        }
    }

    j = 0, k = 0;
    while(j+k<10000)
    {
        double x, y;
        if((j+k+1)%100 == 0)
        {
            x = (outrec[j]/1000)/10.0;
            y = (outrec[j]%1000)/10.0;
            out << x << "\t" << y << endl;
            j++;
        }
        else
        {
            x = (inrec[k]/1000)/10.0;
            y = (inrec[k]%1000)/10.0;
            out << x << "\t" << y << endl;
            k++;
        }
    }
}

int main(int argc, char *argv[])
{
    int itera = atoi(argv[1]);
    fstream in("dot"+string(argv[1]),ios_base::in | ios_base::out | ios_base::trunc);
    ofstream out("graham"+string(argv[1]));
    struct timespec start, end;
    vector<DOT> q;
    DOT mindot = {DBL_MAX,DBL_MAX};
    int min_index, i = 0;

    genq(in);
    in.close(); 
    in.clear();
    in.open("dot"+string(argv[1]));

    while(i<itera)
    {
        DOT t;
        in >> t.x >> t.y;
        q.push_back(t);

        if(t.x < mindot.x){ mindot = t; min_index = q.size()-1; }
        else if(t.x - mindot.x < DBL_MIN)
        {
            if(t.y < mindot.y) { mindot = t; min_index = q.size()-1; }
        }
        i++;
    }
    in.close();

    vector<DOT *> angel;
    for(int i=0,e=q.size();i<e;i++)
    {
        if(i!=min_index) angel.push_back(&q[i]);
    }
    erx = q[min_index].x;
    ery = q[min_index].y;
    
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
    sort(angel.begin(),angel.end(),cmp);

    vector<DOT*> convex(angel.size()+1);
    DOT * v1 = new DOT(), *v2 = new DOT();
    convex[0] = &q[min_index];
    convex[1] = angel[0];
    erx = 0;
    ery = 0;
    int j = 1;

    for(int i=1,e=angel.size();i<e;i++)
    {
        v1->x = angel[i]->x-convex[j]->x;
        v1->y = angel[i]->y-convex[j]->y;
        v2->x = convex[j-1]->x-convex[j]->x;
        v2->y = convex[j-1]->y-convex[j]->y;
        while(!cmp(v1,v2))
        {
            j--;
            v1->x = angel[i]->x-convex[j]->x;
            v1->y = angel[i]->y-convex[j]->y;
            v2->x = convex[j-1]->x-convex[j]->x;
            v2->y = convex[j-1]->y-convex[j]->y;
        }
        j++;
        convex[j] = angel[i];
    }
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end);
    cout << itera << "\t" << (end.tv_sec-start.tv_sec)*1000+(end.tv_nsec-start.tv_nsec)/1000000.0 << endl;
    for(int i=0;i<=j;i++)
    {
        out << convex[i]->x << "\t" << convex[i]->y << endl;
    }
    out << convex[0]->x << "\t" << convex[0]->y << endl;
    out.close();

    return 0;
}
