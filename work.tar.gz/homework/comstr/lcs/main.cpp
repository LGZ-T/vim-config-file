#include <iostream>
#include <string>
#include <fstream>
#include <vector>
using namespace std;

int lcs(string &x, int xindex, string &y, int yindex, string &com)
{
    if(xindex < 0 || yindex < 0) return 0;
    int len = 0;
    string com1, com2;
    if(x[xindex]==y[yindex])
    {
        com.append(1,x[xindex]);
        len = lcs(x, xindex-1, y, yindex-1, com)+1;
    }
    else if(x[xindex]!=y[yindex])
    {
        int l1 = lcs(x,xindex-1,y,yindex,com1);
        int l2 = lcs(x,xindex,y,yindex-1,com2);
        if(l1 >= l2) { len = l1; com.append(com1); }
        else         { len = l2; com.append(com2); }
    }
    return len;
}

void dynalcs(string &x, string &y, string &com)
{
    vector<vector<int> > c(y.size()+1,vector<int>(x.size()+1,0));
    int yi, ye, xi, xe;
    for(yi=1,ye=y.size();yi<=ye;yi++)
    {
        for(xi=1,xe=x.size();xi<=xe;xi++)
        {
            if(x[xi-1]==y[yi-1]) c[yi][xi] = c[yi-1][xi-1]+1;
            else if(c[yi][xi-1]>=c[yi-1][xi]) c[yi][xi] = c[yi][xi-1];
            else c[yi][xi] = c[yi-1][xi];
        }
    }

    yi = y.size();
    xi = x.size();
    while(yi>0 && xi>0)
    {
        if(x[xi-1]==y[yi-1]) { com.append(1,x[xi-1]); xi--; yi--; }
        else if(c[yi][xi-1]>=c[yi-1][xi]) { xi--; }
        else yi--;
    }
}
int main()
{
    ofstream rec("rec"), rec_var("rec_var"), dyn("dyn"), dyn_var("dyn_var");
    struct timespec start, end;
    char str[40][101];
    vector<string> varlen(20,"");
    srand((int)time(0));

    for(int i=0;i<40;i++)
    {
        int j;
        for(j=0;j<10;j++)
        {
            str[i][j] = rand()%26+65;
        }
        str[i][j] = '\0';
    }

    srand((int)time(0));

    for(int i=0;i<10;i++)
    {
        for(int j=0;j<5+i;j++)
        {
            varlen[i*2].push_back(rand()%26+65);
            varlen[i*2+1].push_back(rand()%26+65);
        }
    }

    for(int i=0;i<20;i++)
    {
        string com1, com2; 
        string s1(str[i*2]);
        string s2(str[i*2+1]);
        cout << "#####################" << endl;
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
        lcs(s1,s1.size()-1,s2,s2.size()-1,com1);
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end);
        double t1 = (end.tv_sec-start.tv_sec)*1000+(end.tv_nsec-start.tv_nsec)/1000000.0;
        string r1(com1.rbegin(),com1.rend());

        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
        dynalcs(s1,s2,com2);
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end);
        double t2 = (end.tv_sec-start.tv_sec)*1000+(end.tv_nsec-start.tv_nsec)/1000000.0;
        string r2(com2.rbegin(),com2.rend());

        cout << "s1      :" << s1 << endl;
        cout << "s2      :" << s2 << endl;
        cout << "recurive:" << r1 << "\ttime:" << t1 << endl;
        cout << "dynamic :" << r2 << "\ttime:" << t2 << endl;
        cout << "##############################\n" << endl;
        rec << i << "\t" << t1 << endl;
        dyn << i << "\t" << t2 << endl;
    }

    for(int i=0;i<10;i++)
    {
        string com1, com2; 
        cout << "$$$$$$$$$$$$$$$$$$$$$" << endl;
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
        lcs(varlen[i*2],varlen[i*2].size()-1,varlen[i*2+1],varlen[i*2+1].size(),com1);
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end);
        double t1 = (end.tv_sec-start.tv_sec)*1000+(end.tv_nsec-start.tv_nsec)/1000000.0;
        string r1(com1.rbegin(),com1.rend());

        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
        dynalcs(varlen[i*2],varlen[i*2+1],com2);
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end);
        double t2 = (end.tv_sec-start.tv_sec)*1000+(end.tv_nsec-start.tv_nsec)/1000000.0;
        string r2(com2.rbegin(),com2.rend());

        cout << "s1      :" << varlen[i*2] << endl;
        cout << "s2      :" << varlen[i*2+1] << endl;
        cout << "recurive:" << r1 << "\ttime:" << t1 << endl;
        cout << "dynamic :" << r2 << "\ttime:" << t2 << endl;
        cout << "$$$$$$$$$$$$$$$$$$$$$$\n" << endl;
        rec_var << varlen[i*2].size() << "\t" << t1 << endl;
        dyn_var << varlen[i*2+1].size() << "\t" << t2 << endl;
    }
    return 0;
}
