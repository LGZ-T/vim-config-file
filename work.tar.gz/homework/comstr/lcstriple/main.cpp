#include <iostream>
#include <vector>

using namespace std;

void lcstriple(string &x, string &y, string &z, string &com)
{
    int c[x.size()+1][y.size()+1][z.size()+1];
    int i, ie, j, je, k, ke;
    for(i=0,ie=x.size();i<=ie;i++)
        for(j=0,je=y.size();j<=je;j++)
            c[i][j][0] = 0;

    for(i=0,ie=x.size();i<=ie;i++)
        for(k=0,ke=z.size();k<=ke;k++)
            c[i][0][k] = 0;

    for(j=0,je=y.size();j<=je;j++)
        for(k=0,ke=z.size();k<=ke;k++)
            c[0][j][k] = 0;

    for(i=1,ie=x.size();i<=ie;i++)
    {
        for(j=1,je=y.size();j<=je;j++)
        {
            for(k=1,ke=z.size();k<=ke;k++)
            {
                if(x[i-1]==y[j-1] && y[j-1]==z[k-1]) c[i][j][k] = c[i-1][j-1][k-1] + 1;
                else if(c[i-1][j][k]>=c[i][j-1][k] && c[i-1][j][k]>=c[i][j][k-1]) c[i][j][k] = c[i-1][j][k];
                else if(c[i][j-1][k]>=c[i-1][j][k] && c[i][j-1][k]>=c[i][j][k-1]) c[i][j][k] = c[i][j-1][k];
                else if(c[i][j][k-1]>=c[i-1][j][k] && c[i][j][k-1]>=c[i][j-1][k]) c[i][j][k] = c[i][j][k-1];
            }
        }
    }

    i = x.size();
    j = y.size();
    k = z.size();
    while(i>0 && j>0 && k>0)
    {
        if(x[i-1]==y[j-1] && y[j-1]==z[k-1])
        {
            com.append(1,x[i-1]);
            i--;
            j--;
            k--;
        }
        else if(c[i-1][j][k]>=c[i][j-1][k] && c[i-1][j][k]>=c[i][j][k-1]) i--;
        else if(c[i][j-1][k]>=c[i-1][j][k] && c[i][j-1][k]>=c[i][j][k-1]) j--;
        else if(c[i][j][k-1]>=c[i-1][j][k] && c[i][j][k-1]>=c[i][j-1][k]) k--;

    }
    return;
}

int main()
{
    string com,x,y,z;
    cin >> x >> y >> z;
    lcstriple(x,y,z,com);
    cout << "$$$$$$$$$$$$$$$$$$$$$$$$$" << endl;
    for(int i=com.size()-1;i>=0;i--)
    {
        cout << com[i];
    }
    cout << "\n$$$$$$$$$$$$$$$$$$$$$$$\n\n" << endl;
    return 0;
}
